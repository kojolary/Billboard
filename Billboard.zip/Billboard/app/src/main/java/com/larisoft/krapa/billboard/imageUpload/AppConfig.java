package com.larisoft.krapa.billboard.imageUpload;

public class AppConfig {

    // local
    public static String BASE_URL = "http://192.168.20.137/webservicev2/";

    public static String uploadImage = BASE_URL + "uploadImage.php";
}
