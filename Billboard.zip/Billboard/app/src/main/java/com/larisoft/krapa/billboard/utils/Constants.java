package com.larisoft.krapa.billboard.utils;

public class Constants {

        public static final String TAG_EMAIL = "email";
        public static final String TAG_LOGIN = "login";


}
